package no.taardal.blossom.level;

public class TestLevel extends Level {

    private static final int[][] TILE_MAP = {
            {1, 0, 1, 0},
    };

}
