package no.taardal.blossom.input;

import java.awt.event.MouseAdapter;

public class Mouse extends MouseAdapter {

}
