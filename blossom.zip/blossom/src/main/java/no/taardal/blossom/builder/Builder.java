package no.taardal.blossom.builder;

public interface Builder<T> {

    T build();

}
