package no.taardal.blossom.coordinate;

public enum Precision {

    PIXEL,
    TILE

}
